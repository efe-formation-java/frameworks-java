package fr.formation.main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import fr.formation.entity.Adresse;
import fr.formation.entity.Personne;

public class TestPersonneAdresse {

	public static void main(String[] args) {
		
		
		Adresse a1 = new Adresse("44000", "Nantes");
		Personne p1 = new Personne("Legrand", "Suzon", a1);
		Personne p2 = new Personne("Lepetit", "Marie", new Adresse("29000", "Quimper"));
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("formationPU");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		
		try {
			em.persist(p1);
			em.persist(p2);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			System.out.println("Erreur : " + e.getMessage());
		}
		
		System.out.println("\nListe des personnes :");
		List<Personne> listeP = em.createQuery("From Personne p", Personne.class).getResultList();
		listeP.forEach(p -> System.out.println(p));
		
		Personne pId2 = em.find(Personne.class, 2);
		System.out.println("\nPersonne avec l'id 2 : " + pId2);
		
		Personne pId3 = em.find(Personne.class, 3);
		System.out.println("\nPersonne avec l'id 3 : " + pId3);
		
		et = em.getTransaction();
		et.begin();
		try {
			em.remove(p1);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			System.out.println("Erreur : " + e.getMessage());
		}
		
		// Premier déménagement de Marie
		p2.getAdresse().setCodePostal("56000");
		p2.getAdresse().setVille("Vannes");
		
		et = em.getTransaction();
		et.begin();
		try {
			em.merge(p2);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			System.out.println("Erreur : " + e.getMessage());
		}
		
		// Deuxieme déménagement
		Adresse a3 = new Adresse("22000", "Saint Brieuc");
		p2.setAdresse(a3);
		et = em.getTransaction();
		
		et.begin();
		try {
			em.merge(p2);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			System.out.println("Erreur : " + e.getMessage());
		}
		
		
		em.close();
		emf.close();
	}
}
