package fr.formation.model;

public interface Instrument {

	void afficher();
	void jouer();
}
