package fr.formation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.formation.model.Instrument;
import fr.formation.model.Musicien;

public class AppelSpring {

	public static void main(String[] args) {
		// Chargement l'environnement d'execution de Spring
		
		ApplicationContext ac = new ClassPathXmlApplicationContext("ApplicationContext.xml");

		
		// Récupération de l'instrument créé par Spring
		//Instrument ins = ac.getBean(Instrument.class) ;// injection par type
		
		Instrument ins = ac.getBean("violon", Instrument.class) ;// injection par name
		
		System.out.println("Instrument : ");
		ins.afficher();
		
		
		// Récupération du musicien créé par Spring		
		Musicien mus = ac.getBean(Musicien.class);   // injection par type
		mus.jouerMorceau();
		
		System.out.println("Fin du programme");
	}

}
