package fr.formation;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import fr.formation.entity.Utilisateur;

public class AppelJPA {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("formationPU");
		EntityManager em = emf.createEntityManager();
		
		Utilisateur u1 = new Utilisateur(1, "user1", "azerty");
		Utilisateur u2 = new Utilisateur(2, "user2", "azerty");
		Utilisateur u3 = new Utilisateur(1, "user3", "azerty");
//		System.out.println(u1);

		EntityTransaction et = em.getTransaction();
		
		et.begin();
		
		try {
			em.persist(u1);
			em.persist(u2);
			em.persist(u3);
			et.commit();
			System.out.println("Utilisteur enregistré : OK");
		} catch (Exception e) {
			et.rollback();
			System.out.println("Un probleme est survenu lors de l'ajout : " + e.getMessage());
		}
		
		
		em.close();
		emf.close();
	}
}
