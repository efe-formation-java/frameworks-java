package fr.formation.main;

import java.util.List;

import fr.formation.bean.Livre;
import fr.formation.dao.DaoUtil;
import fr.formation.dao.LivreDao;
import fr.formation.exception.DaoException;

public class TestLivreJPA {

	public static void main(String[] args) {

		Livre l1 = new Livre("La Bête humaine", "Emile Zola", 450);
		Livre l2 = new Livre("Huis clos", "JP Sartre", 350);
		Livre l3 = new Livre("L'étranger", "Albert Camus", 476);
		Livre l4 = new Livre("La Peste", "Albert Camus", 276);

		LivreDao lDao = new LivreDao();
		System.out.println("\nCréation de 4 livres ... ");
		
		try {
			lDao.add(l1);
			lDao.add(l2);
			lDao.add(l3);
			lDao.add(l4);
		} catch (DaoException e) {
			System.out.println(e.getMessage());
		}
		
		List<Livre> listeL = lDao.findAll();
		
		affiche("Liste des livres : ", listeL);
		affiche("Liste des livres triés par titre descendant : ", lDao.findAllOrderByTitreDesc());
		affiche("Liste des livres triés par titre ascendant : ", lDao.findAllOrderByTitreAsc());
		affiche("Liste des livres de Camus : ", lDao.findByAuteurLike("camus"));
		
		System.out.println("\nPremier id : " + lDao.getMinId());
		System.out.println("\nDernier id : " + lDao.getMaxId());

		System.out.println("\nLivre id = 2  : " + lDao.findById(2));
		System.out.println("\nLivre id = 22 : " + lDao.findById(22));

		// Suppression de l1 :
		
		try {
			lDao.delete(l1);
		} catch (DaoException e) {
			System.out.println(e.getMessage());
		}
		
		// Suppression du livre id = 3 :
		
		try {
			lDao.delete(3);
		} catch (DaoException e) {
			System.out.println(e.getMessage());
		}
		
		try {
			l2.setNbPages(354);
			l2.setAuteur("Jean Paul Sartre");
			lDao.update(l2);
		} catch (DaoException e) {
			System.out.println(e.getMessage());
		}
		
		
		affiche("Liste apres modif et supp : ", lDao.findAll());
		
		
		
		DaoUtil.close();
	}

	private static void affiche(String msg, List<Livre> listeL) {
		System.out.println();
		System.out.println(msg);
		for (Livre livre : listeL) {
			System.out.println(livre);
		}
	}

}
