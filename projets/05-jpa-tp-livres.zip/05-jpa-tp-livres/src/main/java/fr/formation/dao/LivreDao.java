package fr.formation.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import fr.formation.bean.Livre;
import fr.formation.exception.DaoException;

public class LivreDao {

	public void add(Livre l) throws DaoException {
		EntityManager em = DaoUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		
		try {
			em.persist(l);
			et.commit();
		}
		catch (Exception e) {
			et.rollback();
			throw new DaoException("Erreur lors de l'ajout du livre " + l + " : " + e.getMessage());
		}
	}
	
	

	public void update(Livre l) throws DaoException {
		EntityManager em = DaoUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		
		try {
			em.merge(l);
			et.commit();
		}
		catch (Exception e) {
			et.rollback();
			throw new DaoException("Erreur lors de la modification du livre " + l + " : " + e.getMessage());
		}
	}		

	public void delete(Livre l) throws DaoException {
		EntityManager em = DaoUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		
		try {
			em.remove(l);
			et.commit();
		}
		catch (Exception e) {
			et.rollback();
			throw new DaoException("Erreur lors de la suppression du livre " + l + " : " + e.getMessage());
		}
	}	
	
	
	public void delete(int id) throws DaoException {
		EntityManager em = DaoUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		
		Livre l = em.find(Livre.class, id);
		
		try {
			em.remove(l);
			et.commit();
		}
		catch (Exception e) {
			et.rollback();
			throw new DaoException("Erreur lors de la modification du livre " + l + " : " + e.getMessage());
		}
	}	
	

	
	public Livre findById(int id) {
		return DaoUtil
				.getEntityManager()
				.find(Livre.class, id);
	}
	
	public List<Livre> findAll(){
		
		String req = "Select Object(l) from Livre l";
		return DaoUtil
				.getEntityManager()
				.createQuery(req, Livre.class)
				.getResultList();
	}
	
	
	public List<Livre> findAllOrderByTitreAsc(){
		
		String req = "Select Object(l) from Livre l Order by l.titre ASC";
		return DaoUtil
				.getEntityManager()
				.createQuery(req, Livre.class)
				.getResultList();
	}
	
	
	public List<Livre> findAllOrderByTitreDesc(){
		
		String req = "Select Object(l) from Livre l Order by l.titre DESC";
		return DaoUtil
				.getEntityManager()
				.createQuery(req, Livre.class)
				.getResultList();
	}
	
	
	public List<Livre> findByAuteurLikeSensitive(String auteur){
		
		String req = "Select Object(l) from Livre l WHERE l.auteur LIKE :aut";
		return DaoUtil
				.getEntityManager()
				.createQuery(req, Livre.class)
				.setParameter("aut", "%" + auteur + "%")
				.getResultList();
	}
	
	
	public List<Livre> findByAuteurLike(String auteur){
		
		String req = "Select Object(l) from Livre l WHERE lower(l.auteur) LIKE :aut";
		return DaoUtil
				.getEntityManager()
				.createQuery(req, Livre.class)
				.setParameter("aut", "%" + auteur.toLowerCase() + "%")
				.getResultList();
	}
	
	public int getMaxId() {
		String req = "Select max(l.id) from Livre l";
		return DaoUtil
				.getEntityManager()
				.createQuery(req, Integer.class)
				.getSingleResult();
				
	}
	
	public int getMinId() {
		String req = "Select min(l.id) from Livre l";
		return DaoUtil
				.getEntityManager()
				.createQuery(req, Integer.class)
				.getSingleResult();
				
	}
	
}
