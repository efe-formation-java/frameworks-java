package fr.formation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import fr.formation.entity.Adresse;
import fr.formation.entity.Personne;
import fr.formation.service.PersonneService;

@SpringBootApplication
public class Application implements CommandLineRunner{

	@Autowired
	PersonneService personneService;
	
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Personne p1 = new Personne("Lebleu", "Joe", new Adresse("44000", "Nantes"));
		Personne p2 = new Personne("Levert", "Aline", new Adresse("56000", "Vannes"));
		Personne p3 = new Personne("Leorange", "Marc", new Adresse("44700", "Orvault"));
		Personne p4 = new Personne("Lerouge", "Marie", new Adresse("29000", "Quimper"));
		Personne p5 = new Personne("", "", new Adresse("29000", "Quimper"));
		
		personneService.ajouterPersonne(p1);
		personneService.ajouterPersonne(p2);
		personneService.ajouterPersonne(p3);
		personneService.ajouterPersonne(p4);
		
		try {
			personneService.ajouterPersonne(p5);
		} catch (Exception e) {
			System.out.println("Pb lors de l'enreg de p5 : " + e.getMessage());
		}
		
		List<Personne> listeP = personneService.trouverToutesLesPersonnes();
		System.out.println("\nListe des personnes en base : ");
		listeP.forEach(p -> System.out.println("    - " + p));
		
		
		
	}

}
