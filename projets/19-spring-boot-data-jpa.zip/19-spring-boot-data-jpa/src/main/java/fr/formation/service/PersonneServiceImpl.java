package fr.formation.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.formation.entity.Personne;
import fr.formation.repository.PersonneDao;

@Service
public class PersonneServiceImpl implements PersonneService {

	@Autowired
	PersonneDao personneDao;
	
	
	@Override
	public void ajouterPersonne(Personne p) {
		if (p == null) {
			throw new RuntimeException("Personne nulle");
		}
		if (p.getNom() == null || p.getNom().isBlank()) {
			throw new RuntimeException("Le nom est obligatoire");
		}
		
		personneDao.save(p);
		
	}

	@Override
	public List<Personne> trouverToutesLesPersonnes() {
		return personneDao.findAll();
	}

	@Override
	public Personne trouverUnePersonne(int id) {
		
		Optional<Personne> opt = personneDao.findById(id);
		if (opt.isEmpty())
			return null;
		else
			return opt.get();
	}

}
