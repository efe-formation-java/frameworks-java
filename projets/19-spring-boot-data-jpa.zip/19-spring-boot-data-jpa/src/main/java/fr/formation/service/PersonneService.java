package fr.formation.service;

import java.util.List;

import fr.formation.entity.Personne;

public interface PersonneService {

	void ajouterPersonne(Personne p);
	List<Personne> trouverToutesLesPersonnes();
	
	Personne trouverUnePersonne(int id);
}
