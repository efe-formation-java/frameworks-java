package fr.formation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.formation.entity.Personne;

public interface PersonneDao extends JpaRepository<Personne, Integer> {

}
