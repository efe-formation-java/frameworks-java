package fr.formation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.formation.model.Instrument;
import fr.formation.model.Musicien;

public class AppelSpring {

	public static void main(String[] args) {
		// Chargement l'environnement d'execution de Spring
		
		ApplicationContext ac = new ClassPathXmlApplicationContext("ApplicationContext.xml");

		
		Musicien mus = ac.getBean(Musicien.class);
		mus.jouerMorceau();
		
		System.out.println("Fin du programme");
	}

}
