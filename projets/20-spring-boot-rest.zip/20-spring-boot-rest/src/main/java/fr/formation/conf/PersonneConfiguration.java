package fr.formation.conf;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import fr.formation.model.Adresse;
import fr.formation.model.Personne;

@Configuration
public class PersonneConfiguration {

	
	@Bean
	List<Personne> generateListPerson(){
		List<Personne> liste = new ArrayList<>();
		liste.add(new Personne("Leorange", "Amélie", new Adresse("22000", "Saint Brieuc")));
		return liste;
	}
	
}
