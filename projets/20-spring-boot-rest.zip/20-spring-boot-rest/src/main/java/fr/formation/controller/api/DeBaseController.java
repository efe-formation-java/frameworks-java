package fr.formation.controller.api;

import java.util.Random;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DeBaseController {

	// Verbe : GET
	// path : /bonjour
	@GetMapping("/bonjour")
	public String bonjour() {
		
		return "bonjour";
	}
	
	
	@GetMapping("/alea")
	public int alea() {
		int valeur = new Random().nextInt(100);
		return valeur;
	}
	
	@GetMapping("/aleainf50")
	public ResponseEntity<Integer> aleainf50() {
		int valeur = new Random().nextInt(100);
		ResponseEntity<Integer> re;
		// Si valeur < 50 -> je renvoie la valeur
		// Si valeur >=50 -> Pas OK
		if (valeur < 50) {
			re = new ResponseEntity<>(valeur, HttpStatus.OK);
		}
		else {
			re = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		
		return re;
	}
	
	@GetMapping("/bonjour/{nom}")
	public String bonjourParam(@PathVariable("nom") String nomPersonne) {
		
		return "Bien le bonjour, " + nomPersonne + " !";
	}

	
	@GetMapping("/bonjour/{nom}/{prenom}/{age}")
	public String bonjourParams(
			@PathVariable("nom") String nomPersonne,
			@PathVariable("prenom") String prenomPersonne,
			@PathVariable("age") Integer agePersonne) {
		
		return "Bien le bonjour, " + prenomPersonne+ " " + nomPersonne + " ! Vous avez " + agePersonne +  " ans";
	}

	// localhost:8080/ajouter?nom=Lebleu&prenom=Aline&age=42
	@PostMapping("/ajouter")
	public String ajouter(String nom, String prenom, Integer age) {
		return "Bonjour, " + prenom+ " " + nom + " ! Vous avez " + age +  " ans";

	}
	
	
	
	
	
}
