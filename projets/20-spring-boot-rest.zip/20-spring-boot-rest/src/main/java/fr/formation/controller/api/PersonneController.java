package fr.formation.controller.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
	
import fr.formation.model.Adresse;
import fr.formation.model.Personne;

@RestController
@RequestMapping("/personne")
public class PersonneController {

	@Autowired
	List<Personne> listeP;
	

	
	@GetMapping("/une")
	Personne getPersonne() {
		return new Personne("Lebleu", "Margot", new Adresse("75001", "Paris"));
	}
	
	
	@GetMapping()
	List<Personne> liste(){
		return listeP;
	}
	
	@PostMapping()
	ResponseEntity<Void> ajouterPers(@RequestBody Personne nouveau) {
		System.out.println("Personne recupérée : " + nouveau);
		listeP.add(nouveau);
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}
	
	@DeleteMapping("/{id}") // 0, 1, 2
	void suppPers(@PathVariable("id") int id) {
		System.out.println("Suppression de la " + id + "eme personne");
		listeP.remove(id);
	}
	
	
}
