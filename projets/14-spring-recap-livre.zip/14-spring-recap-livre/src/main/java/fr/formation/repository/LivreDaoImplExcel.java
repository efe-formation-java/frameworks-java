package fr.formation.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import fr.formation.model.Livre;


@Repository
public class LivreDaoImplExcel implements LivreDao {

	@Autowired
	private Livre livre;
	
	@Override
	public Livre findById(int id) {
		System.out.println("FindbyId en Excel");
		livre.setId(id);
		return livre;
	}

}
