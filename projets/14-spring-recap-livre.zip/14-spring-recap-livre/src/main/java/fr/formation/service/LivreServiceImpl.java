package fr.formation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.formation.model.Livre;
import fr.formation.repository.LivreDao;



@Service
public class LivreServiceImpl implements LivreService {

	@Autowired
	private LivreDao livreDao;
	
	@Override
	public Livre trouverLivre(int id) {
		
		if (id < 0)
			throw new RuntimeException("L'id doit être positif");
		return livreDao.findById(id);
	}

}
