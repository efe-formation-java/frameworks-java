package fr.formation.controller;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import fr.formation.model.Livre;
import fr.formation.service.LivreService;


@Controller
public class LivreControllerImpl implements LivreController {

	@Autowired
	private LivreService livreService;
	
	@Override
	public Livre apiRestTrouver() {
		Livre recup = null;
		Scanner sc = new Scanner(System.in);
		System.out.println("id du livre recherché : ");
		int id = sc.nextInt();
		
		try {
			recup = livreService.trouverLivre(id);
		} catch (Exception e) {
			System.out.println("Une erreur est survenue: " + e.getMessage());
		}
		
		sc.close();
		return recup;
	}

}
