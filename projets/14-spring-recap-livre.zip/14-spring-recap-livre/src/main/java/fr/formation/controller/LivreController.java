package fr.formation.controller;

import fr.formation.model.Livre;

public interface LivreController {

	
	Livre apiRestTrouver();
}
