package fr.formation.repository;

import fr.formation.model.Livre;

public interface LivreDao {

	Livre findById(int id);
}
