package fr.formation.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import fr.formation.model.Livre;

@Configuration
@ComponentScan(basePackages = {"fr.formation.repository", "fr.formation.service", "fr.formation.controller"})
public class LivreConfiguration {

	
	@Bean
	public Livre getLivre() {
		return new Livre(4, "Baudelaire", "Les fleurs du mal");
	}
	
}
