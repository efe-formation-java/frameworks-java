package fr.formation.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import fr.formation.model.Livre;


//@Repository
public class LivreDaoImplBdd implements LivreDao {

	@Autowired
	private Livre livre;
	
	@Override
	public Livre findById(int id) {
		System.out.println("FindbyId en base de données");
		livre.setId(id);
		return livre;
	}

}
