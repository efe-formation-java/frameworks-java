package fr.formation.model;

public class Livre {

	private int id;
	private String auteur;
	private String titre;

	public Livre() {
	}

	public Livre(int id, String auteur, String titre) {
		this.id = id;
		this.auteur = auteur;
		this.titre = titre;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAuteur() {
		return auteur;
	}

	public void setAuteur(String auteur) {
		this.auteur = auteur;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	@Override
	public String toString() {
		return "Livre [id=" + id + ", auteur=" + auteur + ", titre=" + titre + "]";
	}

}
