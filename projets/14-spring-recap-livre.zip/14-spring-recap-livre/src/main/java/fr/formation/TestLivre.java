package fr.formation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import fr.formation.config.LivreConfiguration;
import fr.formation.controller.LivreController;
import fr.formation.model.Livre;

public class TestLivre {

	
	public static void main(String[] args) {
		
		ApplicationContext ac = new AnnotationConfigApplicationContext(LivreConfiguration.class);
/*		
		Livre l = ac.getBean(Livre.class);
		System.out.println("Livre de base : " + l);
		
		LivreDao lDao = ac.getBean(LivreDao.class);
		Livre recupDao = lDao.findById(9);
		System.out.println("Livre recupere par LivreDao : " + recupDao);
		
		LivreService livreService = ac.getBean(LivreService.class);

		Livre recupService = livreService.trouverLivre(15); 
		System.out.println(recupService);
*/		
		LivreController controller = ac.getBean(LivreController.class);
		Livre recup = controller.apiRestTrouver();
		System.out.println(recup);
		
		System.out.println("Fin du programme");
	}
}
