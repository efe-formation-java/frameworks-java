package fr.formation.service;

import fr.formation.model.Livre;

public interface LivreService {

	
	Livre trouverLivre(int id);
}
