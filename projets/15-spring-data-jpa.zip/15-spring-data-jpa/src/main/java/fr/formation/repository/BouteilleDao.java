package fr.formation.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.formation.model.Bouteille;

public interface BouteilleDao extends JpaRepository<Bouteille, Integer> {
	
	
	List<Bouteille> findByOrderByMillesimeAsc();
	List<Bouteille> findByOrderByMillesimeDesc();
	
	List<Bouteille> findByOrderByProprietaireNomAscProprietairePrenomAsc();
	
	List<Bouteille> findByProprietaireNom(String nom);

	List<Bouteille> findByNomStartingWith(String nom);
}
