package fr.formation.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BouteilleDeVin")
public class Bouteille {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String nom;
	private String couleur;
	private int millesime;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Proprietaire proprietaire;

	public Bouteille() {
	}

	public Bouteille(String nom, String couleur, int millesime, Proprietaire proprietaire) {
		this.nom = nom;
		this.couleur = couleur;
		this.millesime = millesime;
		this.proprietaire = proprietaire;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getCouleur() {
		return couleur;
	}

	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}

	public int getMillesime() {
		return millesime;
	}

	public void setMillesime(int millesime) {
		this.millesime = millesime;
	}

	public Proprietaire getProprietaire() {
		return proprietaire;
	}

	public void setProprietaire(Proprietaire proprietaire) {
		this.proprietaire = proprietaire;
	}

	@Override
	public String toString() {
		return "Bouteille [id=" + id + ", nom=" + nom + ", couleur=" + couleur + ", millesime=" + millesime
				+ ", proprietaire=" + proprietaire + "]";
	}

	
	
	
}
