package fr.formation.main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import fr.formation.conf.MaCaveConfiguration;
import fr.formation.model.Bouteille;
import fr.formation.model.Proprietaire;
import fr.formation.repository.BouteilleDao;

public class MonProgrammeCave {
	public static void main(String[] args) {
		
		
		ApplicationContext ac = new AnnotationConfigApplicationContext(MaCaveConfiguration.class);
		
		Proprietaire p1 = new Proprietaire("Legrand", "Joe");
		Bouteille b1 = new Bouteille("Chateau Le Clos", "Rouge", 2001, p1);
		
		Bouteille b2 = new Bouteille("La voyelle de la terre", "Blanc", 2011, new Proprietaire("Lepetit", "Suzon"));
		Bouteille b3 = new Bouteille("Chateau Y", "Blanc", 2014, new Proprietaire("Lepetit", "Aline"));
		Bouteille b4 = new Bouteille("Chateau de la terre", "Rouge", 1985, new Proprietaire("Lepetit", "Charles"));
		Bouteille b5 = new Bouteille("Clos du Sud", "Rosé", 2020, new Proprietaire("Lemoyen", "Marc"));
		
		
		BouteilleDao bdao = ac.getBean(BouteilleDao.class);
		
		bdao.save(b1);
		bdao.save(b2);
		bdao.save(b3);
		bdao.save(b4);
		bdao.save(b5);
		
		System.out.println("\nListe des bouteilles : ");
		List<Bouteille> listeB = bdao.findAll();
		listeB.forEach(b -> System.out.println(b));
		
		
		System.out.println("\nListe des bouteilles triée par millesime ASC : ");
		listeB = bdao.findByOrderByMillesimeAsc();
		listeB.forEach(b -> System.out.println(b));
		
		
		System.out.println("\nListe des bouteilles triée par millesime DESC : ");
		listeB = bdao.findByOrderByMillesimeDesc();
		listeB.forEach(b -> System.out.println(b));
		
		System.out.println("\nListe des bouteilles triée par leur proprietaire (nom, prenom): ");
		listeB = bdao.findByOrderByProprietaireNomAscProprietairePrenomAsc();
		listeB.forEach(b -> System.out.println(b));
		
		System.out.println("\nListe des bouteilles dont le proprietaire s'appelle Lepetit ");
		listeB = bdao.findByProprietaireNom("Lepetit");
		listeB.forEach(b -> System.out.println(b));

		System.out.println("\nListe des bouteilles dont le nom commence par 'Chateau' ");
		listeB = bdao.findByNomStartingWith("Chateau");
		listeB.forEach(b -> System.out.println(b));
		
		
		
		
		bdao.delete(2);
		
		b1.setNom("Chateau La close");
		b1.getProprietaire().setPrenom("Joey");
		bdao.save(b1);
		
		
		System.out.println("\nListe des bouteilles : ");
		listeB = bdao.findAll();
		listeB.forEach(b -> System.out.println(b));
		
		
		System.out.println("Fin du programme");
	}

}
