package fr.formation.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import fr.formation.model.Personne3;

@Configuration
public class Personne3Configuration {

	
	@Bean(name="president")
	Personne3 personne31() {
		return new Personne3("Lerouge", "Suzon", 55);
	}
	
	@Bean
//	@Bean(name = "personne32")
	Personne3 personne32() {
		return new Personne3("Lerouge", "Jeanne", 52);
	}
	
	@Bean
	Personne3 tresoriere() {
		return new Personne3("Lerouge", "Anne", 52);
	}
}
