package fr.formation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import fr.formation.model.Personne1;
import fr.formation.model.Personne2;
import fr.formation.model.Personne3;
import fr.formation.model.Personne4;

@SpringBootApplication
public class Application implements CommandLineRunner {

	
	@Autowired
	private Personne1 p1;
	
	@Autowired
	private Personne2 p2;
	
	@Autowired
	@Qualifier("president")
	private Personne3 p3;
	
	
	@Autowired
	@Qualifier("personne32")
	private Personne3 secretaire;
	
	@Autowired
	private Personne3 tresoriere;
	
	
	@Autowired
	private Personne4 drh;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Bonjour");
		System.out.println("p1 : " + p1);
		System.out.println("p2 : " + p2);
		System.out.println("p3 : " + p3);
		System.out.println("secretaire : " + secretaire);
		System.out.println("tresoriere : " + tresoriere);
		System.out.println("drh : " + drh);
		
	}

}
