package fr.formation.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import fr.formation.model.Personne4;

@Configuration
public class Personne4Configuration {

	
	@Bean
	@ConditionalOnProperty(name = "usine", havingValue = "nantes")
	Personne4 drhNantes() {
		return new Personne4("Lechataignier", "Valentin", 32);
	}

	@Bean
	@ConditionalOnProperty(name = "usine", havingValue = "marseille")
	Personne4 drhMarseille() {
		return new Personne4("Lechene", "Salomée", 23);
	}
	
}
