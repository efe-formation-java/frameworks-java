package fr.formation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class TestConnexion {

	private static final String SELECT = "SELECT id, nom, prenom, age FROM Personne";
	private static final String INSERT = "INSERT INTO Personne (nom, prenom, age) VALUES (?, ?, ?)";
	
	
	public static void main(String[] args) {
		
		try {
			Class.forName("org.h2.Driver");
			System.out.println("Chargement driver effectué ...");
			
			Connection conn = DriverManager.getConnection("jdbc:h2:~/formation", "form", "ation");
			System.out.println("Connexion effectuée ...");
			
			
			PreparedStatement pstt = conn.prepareStatement(INSERT);
			pstt.setString(1, "Leboulot");
			pstt.setString(2, "Marc");
			pstt.setInt(3, 63);
			
			pstt.executeUpdate();
			System.out.println("Enregistrement effectué");
			pstt.close();

			Statement stt = conn.createStatement();
			ResultSet rs = stt.executeQuery(SELECT);
			
			while(rs.next()) {
				//int id = rs.getInt("id");
				int id = rs.getInt(1);
				String nom = rs.getString("nom");
				String prenom = rs.getString(3);
				int age = rs.getInt("age");
				
				System.out.println(id + " : " + prenom +  " " + nom + " (" + age + " ans)");
			}
			
			rs.close();
			stt.close();
			conn.close();
			
		} catch (ClassNotFoundException e) {
			System.out.println("Driver non trouvé ...");
		} catch (SQLException e) {
			System.out.println("Connexion à la base non effectuée : " + e.getMessage());
		}
		
		
		
		
		
		
		
		System.out.println("Fin du programme");
	}
}
