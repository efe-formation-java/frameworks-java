package fr.formation.main;

import java.time.LocalDate;
import java.util.List;

import fr.formation.dal.DaoUtil;
import fr.formation.dal.PersonneDao;
import fr.formation.entity.Personne;
import fr.formation.exception.PersonneException;

public class TestJPA {

	public static void main(String[] args) {
		
		Personne p1 = new Personne("Lebleu", "Joe");
		Personne p2 = new Personne("Levert", "Anne", LocalDate.of(1986, 4, 3));
		Personne p3 = new Personne("Lerouge", "ALine", LocalDate.of(2001, 7, 14));
		Personne p4 = new Personne("Leorange", "jack");
		Personne p5 = new Personne("Leviolet", null);

		
		System.out.println("p1 avant enreg : " + p1);
		
		PersonneDao pDao = new PersonneDao();
		
		try {
			pDao.add(p1);
			pDao.add(p2);
			pDao.add(p3);
			pDao.add(p4);
			pDao.add(p5);
		} catch (PersonneException e) {
			System.out.println(e.getMessage());
		}
		
		System.out.println("p1 apres enreg : " + p1);

		System.out.println("\nListe des personnes en base :");
		List<Personne> listeP = pDao.findAll();
		listeP.forEach(p -> System.out.println("   - " + p));
		
		
		DaoUtil.close();
	}

}
