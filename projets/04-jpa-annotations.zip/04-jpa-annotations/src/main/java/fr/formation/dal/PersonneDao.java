package fr.formation.dal;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import fr.formation.entity.Personne;
import fr.formation.exception.PersonneException;

public class PersonneDao {

	
	public List<Personne> findAll(){
		// Pas SQL : JPQL : Java Persistence Query Language
		String requete1 = "Select Object(p) From Personne p";
		String requete2 = "Select p From Personne p";
		String requete3 = "From Personne p";
		
		List<Personne> listeP =  DaoUtil
									.getEntityManager()
									.createQuery(requete3, Personne.class)
									.getResultList();
		return listeP;
	}
	
	
	public Personne findById(int id) {
		return DaoUtil.getEntityManager().find(Personne.class, id);
	}
	
	
	
	public void add(Personne p) throws PersonneException {
		EntityManager em = DaoUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		
		try {
			em.persist(p); // Insert Into
			et.commit();
		} catch (Exception e) {
			et.rollback();
			throw new PersonneException("Probleme lors de l'ajout de " + p +  " : " + e.getMessage());
		}
	}
	
	
	
	public void update(Personne p) throws PersonneException {
		EntityManager em = DaoUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		
		try {
			em.merge(p); // Update
			et.commit();
		} catch (Exception e) {
			et.rollback();
			throw new PersonneException("Probleme lors de la modif de " + p +  " : " + e.getMessage());
		}
	}

}
