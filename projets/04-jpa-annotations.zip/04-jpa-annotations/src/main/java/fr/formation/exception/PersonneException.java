package fr.formation.exception;

public class PersonneException extends Exception{
	private static final long serialVersionUID = 1L;

	public PersonneException(String message) {
		super(message);
	}

}
