package fr.formation.main;

import fr.formation.dal.CiviliteDao;
import fr.formation.dal.DaoUtil;
import fr.formation.entity.Civilite;

public class GestionCivilite {

	public static void main(String[] args) {
		
		Civilite m = new Civilite("M", "Monsieur");
		Civilite mlle = new Civilite("Mlle", "Mademoiselle");
		Civilite mme = new Civilite("Mme", "Madame");
		
		CiviliteDao cDao = new CiviliteDao();
		
		cDao.add(mme);
		cDao.add(mlle);
		cDao.add(m);
		
		DaoUtil.close();
	}
}
