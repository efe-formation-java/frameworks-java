package fr.formation.main;

import fr.formation.dal.CiviliteDao;
import fr.formation.dal.DaoUtil;
import fr.formation.dal.PersonneDao;
import fr.formation.entity.Civilite;
import fr.formation.entity.Personne;

public class GestionPersonnesAvecCivilite {

	public static void main(String[] args) {
		CiviliteDao cDao = new CiviliteDao();
		PersonneDao pDao = new PersonneDao();
		
		Civilite madame = cDao.findById("Mme");
		Civilite madeselle = cDao.findById("Mlle");
		Civilite mons = cDao.findById("M");
		
		Personne p1 = new Personne("Legrand", "Joe", mons);
		Personne p2 = new Personne("Lepetit", "Anne", madeselle);
		Personne p3 = new Personne("Lemoyen", "Marie", madame);
		
		pDao.add(p1);
		pDao.add(p2);
		pDao.add(p3);
		
		DaoUtil.close();
	}
	
}
