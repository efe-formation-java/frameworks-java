package fr.formation.dal;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import fr.formation.entity.Civilite;
import fr.formation.entity.Personne;

public class PersonneDao {

	public void add(Personne p)  {
		EntityManager em = DaoUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		
		try {
			em.persist(p);
			et.commit();
		}
		catch (Exception e) {
			e.printStackTrace();
			et.rollback();
		}
	}
	
	

	
	public Personne findById(int id) {
		return DaoUtil
				.getEntityManager()
				.find(Personne.class, id);
	}
	
	public List<Personne> findAll(){
		
		String req = "Select Object(p) from Personne p";
		return DaoUtil
				.getEntityManager()
				.createQuery(req, Personne.class)
				.getResultList();
	}
	
}
