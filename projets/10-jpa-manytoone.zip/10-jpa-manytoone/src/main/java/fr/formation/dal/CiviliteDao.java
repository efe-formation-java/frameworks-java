package fr.formation.dal;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import fr.formation.entity.Civilite;

public class CiviliteDao {

	public void add(Civilite c)  {
		EntityManager em = DaoUtil.getEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		
		try {
			em.persist(c);
			et.commit();
		}
		catch (Exception e) {
			e.printStackTrace();
			et.rollback();
		}
	}
	
	

	
	public Civilite findById(String cle) {
		return DaoUtil
				.getEntityManager()
				.find(Civilite.class, cle);
	}
	
	public List<Civilite> findAll(){
		
		String req = "Select Object(c) from Civilite c";
		return DaoUtil
				.getEntityManager()
				.createQuery(req, Civilite.class)
				.getResultList();
	}
	
}
