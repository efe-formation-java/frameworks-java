package fr.formation.main;

import java.util.List;

import fr.formation.dal.CiviliteDao;
import fr.formation.dal.DaoUtil;
import fr.formation.dal.PersonneDao;
import fr.formation.entity.Civilite;
import fr.formation.entity.Personne;

public class RecupPersonnesAvecCivilite {

	public static void main(String[] args) {
		PersonneDao pDao = new PersonneDao();

		List<Personne> liste = pDao.findAll();
		
		liste.forEach(p -> System.out.println(p));
		
		DaoUtil.close();
	}
	
}
