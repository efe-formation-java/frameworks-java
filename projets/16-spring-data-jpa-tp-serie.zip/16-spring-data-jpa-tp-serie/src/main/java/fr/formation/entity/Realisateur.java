package fr.formation.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class Realisateur extends Personne {

	
	public Realisateur() {
	}
	

	
	public Realisateur(String nom, String prenom) {
		super(nom, prenom);
	}

	@Override
	public String toString() {
		return "Realisateur : " + super.toString();
	}
}
