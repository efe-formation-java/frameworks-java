package fr.formation.controller;

import fr.formation.entity.Serie;

public interface SerieController {

	void ajouterSerie(Serie s);
	void afficherListeSeries();
}
