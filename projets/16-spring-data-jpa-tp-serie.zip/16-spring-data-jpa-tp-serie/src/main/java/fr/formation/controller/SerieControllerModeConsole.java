package fr.formation.controller;

import java.util.List;

import fr.formation.entity.Serie;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import fr.formation.entity.Acteur;
import fr.formation.service.SerieService;
import fr.formation.service.ServiceException;


@Controller
public class SerieControllerModeConsole implements SerieController {

	@Autowired
	private SerieService serieService;
	
	

	@Override
	public void afficherListeSeries() {
		
		System.out.println("\nListe des séries :");
		serieService.listerSeries().forEach(s -> System.out.println(s));

		System.out.println("\nListe des séries triés par titre :");
		serieService.listerSeriesTrieParTitre().forEach(s -> System.out.println(s));

		System.out.println("\nListe des séries triés par titre inv :");
		serieService.listerSeriesTrieParTitreInvers().forEach(s -> System.out.println(s));
/*
		System.out.println("\nListe des séries triés par ordre chrono de la premiere saison :");
		serieService.listerSeriesTrieParAnneeCroissant1ereSaison().forEach(s -> System.out.println(s));
		
		System.out.println("\nListe des séries triés par ordre chrono de la premiere saison inv :");
		serieService.listerSeriesTrieParAnneeDecroissant1ereSaison().forEach(s -> System.out.println(s));

		System.out.println("\nListe des séries triés par nombre d'épisodes total Asc :");
		serieService.listerSeriesTrieParNombreEpisodesTotalAsc().forEach(s -> System.out.println(s));

		System.out.println("\nListe des séries triés par nombre d'épisodes total Desc :");
		serieService.listerSeriesTrieParNombreEpisodesTotalDesc().forEach(s -> System.out.println(s));
*/
		System.out.println("\nListe des séries de Nakache :");
		serieService.listerSeriesParRealisateur("Nakache").forEach(s -> System.out.println(s));
		
		System.out.println("\nListe des séries de Lelouch :");
		serieService.listerSeriesParRealisateur("Lelouch").forEach(s -> System.out.println(s));

		System.out.println("\nListe des séries de Chamoux :");
		serieService.listerSeriesParRealisateur("Chamoux").forEach(s -> System.out.println(s));

		System.out.println("\nListe des séries de 'Ma'' :");
		serieService.listerSeriesParRealisateur("Ma").forEach(s -> System.out.println(s));

		System.out.println("\nListe des séries avec  'Nie':");
		serieService.listerSeriesParActeur("Nie").forEach(s -> System.out.println(s));

		System.out.println("\nListe des séries avec titre 'h' :");
		serieService.listerSeriesParTitre("h").forEach(s -> System.out.println(s));

		System.out.println("\nListe de tous les acteurs:");
		serieService.listerTouslesActeurs().forEach(a -> System.out.println(a));


	}



	@Override
	public void ajouterSerie(Serie s) {
		try {
			serieService.ajouterSerie(s);
		} catch (ServiceException e) {
			System.out.println(e.getMessage());
		}
		
	}

}
