package fr.formation.repository;

import java.util.List;
import java.util.Map;

import fr.formation.entity.Acteur;
import fr.formation.entity.Serie;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


public interface SerieDao extends JpaRepository<Serie, Integer> {


    List<Serie> findByOrderByTitreAsc();

    List<Serie> findByOrderByTitreDesc();
/*
    @Query("select distinct s From Serie s JOIN s.saisons saisons  group by s, saisons.annee order by saisons.annee Asc")
    List<Serie> findOrderBySaisonsAnneeAsc();

    @Query("select distinct s From Serie s JOIN s.saisons saisons  group by s, saisons.annee order by saisons.annee Desc")
    List<Serie> findOrderBySaisonsAnneeDesc();

    @Query("select s From Serie s JOIN s.saisons saisons  group by s order by SUM(saisons.nbEpisodes) Asc")
    List<Serie> findOrderByNombreEpisodesTotalAsc();

    @Query("select distinct s From Serie s JOIN s.saisons saisons  group by s order by SUM(saisons.nbEpisodes) Desc")
    List<Serie> findOrderByNombreEpisodesTotalDesc();
*/
    List<Serie> findDistinctBySaisonsRealisateurNomContainingOrSaisonsRealisateurPrenomContaining(String nom, String prenom);

    List<Serie> findDistinctBySaisonsActeursNomContainingOrSaisonsActeursPrenomContaining(String nom, String prenom);

    List<Serie> findByTitreContaining(String titre);

    // @Query("select Object(a) From Acteur a, Serie s join s.saisons saisons join saisons.acteurs acteurs where acteurs.id = a.id")
   @Query("select Object(acteurs) From Serie s join s.saisons saisons join saisons.acteurs acteurs")
    List<Acteur> findActeurs();

}
