package fr.formation.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class Acteur extends Personne {
	private String role;
	public Acteur() {
		// super(); est appelé par défaut
	}

	public Acteur(String nom, String prenom, String role) {
		super(nom, prenom);
		this.role = role;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "Acteur : " +super.toString() + ", role = " + this.role;
	}
}
