package fr.formation.main;

import java.util.ArrayList;
import java.util.List;

import fr.formation.entity.Saison;
import fr.formation.entity.Serie;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import fr.formation.conf.ApplicationConfiguration;
import fr.formation.controller.SerieController;
import fr.formation.entity.Acteur;
import fr.formation.entity.Realisateur;

public class TestSeries {
	public static void main(String[] args) {
		

		ApplicationContext ac = new AnnotationConfigApplicationContext(ApplicationConfiguration.class);
		
		
		SerieController fc = ac.getBean(SerieController.class);

		// Série 1
		List<Acteur> acteurs1 = new ArrayList<Acteur>();
		acteurs1.add(new Acteur("Pierrot", "Frédéric", "Philippe Dayan"));
		acteurs1.add(new Acteur("Thierry", "Mélanie", "Ariane"));
		acteurs1.add(new Acteur("Kateb", "Reda", "Adel Chibane"));
		acteurs1.add(new Acteur("Brunnquell", "Celeste", "Camille"));

		List<Acteur> acteurs2 = new ArrayList<Acteur>();
		acteurs2.add(new Acteur("Pierrot", "Frédéric", "Philippe Dayan"));
		acteurs2.add(new Acteur("Haidara", "Eye", "Ines"));
		acteurs2.add(new Acteur("Lindon", "Suzanne", "Lydia"));
		acteurs2.add(new Acteur("Weber", "Jacques", "Alain"));

		Saison s1 = new Saison(1, 2019, 35, new Realisateur("Nakache", "Olivier"),acteurs1);
		Saison s2 = new Saison(2, 2021, 35, new Realisateur("Toledano", "Eric"),acteurs2);

		Serie serie1 = new Serie("En thérapie", List.of(s1, s2));

		// Série 2

		List<Acteur> acteurs3 = new ArrayList<Acteur>();
		acteurs3.add(new Acteur("Attal", "Yvan", "Darius Asram"));
		acteurs3.add(new Acteur("Marillier", "Garance", "Nora"));
		acteurs3.add(new Acteur("Azoulay", "Anne", "Beat"));
		acteurs3.add(new Acteur("Schneider", "Niels", "Caron"));

		Saison s3 = new Saison(1, 2018, 6, new Realisateur("Schapira", "Manuel"),acteurs3);
		Serie serie2 = new Serie("Ad Vitam", List.of(s3));


		// Série 3
		List<Acteur> acteurs4 = new ArrayList<Acteur>();
		acteurs4.add(new Acteur("Etienne", "Pauline", "Melissa"));
		acteurs4.add(new Acteur("Grandhomme", "Nicolas", "Eric"));
		Saison s4 = new Saison(1, 2020, 22, new Realisateur("Chamoux", "Maxime"),acteurs4);

		List<Acteur> acteurs5 = new ArrayList<Acteur>();
		acteurs5.add(new Acteur("Etienne", "Pauline", "Melissa"));
		acteurs5.add(new Acteur("Grandhomme", "Nicolas", "Eric"));
		Saison s5 = new Saison(2, 2021, 22, new Realisateur("Chamoux", "Maxime"),acteurs5);

		Serie serie3 = new Serie("18h30", List.of(s4, s5));

		fc.ajouterSerie(serie2);
		fc.ajouterSerie(serie1);
		fc.ajouterSerie(serie3);

		fc.afficherListeSeries();
		
		
		((AnnotationConfigApplicationContext)ac).close();
	}
}
