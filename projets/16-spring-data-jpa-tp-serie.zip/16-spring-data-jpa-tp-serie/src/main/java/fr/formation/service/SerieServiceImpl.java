package fr.formation.service;

import java.util.List;

import fr.formation.entity.Acteur;
import fr.formation.entity.Serie;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.formation.repository.SerieDao;


@Service
public class SerieServiceImpl implements SerieService {

	@Autowired
	private SerieDao dao;
	
	@Override
	public void ajouterSerie(Serie s) throws ServiceException {
		// regles métier
		dao.save(s);
	}

	@Override
	public void modifierSerie(Serie s) throws ServiceException {
		dao.save(s);
	}

	@Override
	public void supprimerSerie(Serie s) {
		dao.delete(s);
	}

	@Override
	public List<Serie> listerSeries() {
		return dao.findAll();
	}

	@Override
	public Serie trouverSerie(int id) {
		return dao.findOne(id);
	}

	@Override
	public List<Serie> listerSeriesTrieParTitre() {
		return dao.findByOrderByTitreAsc();
	}

	@Override
	public List<Serie> listerSeriesTrieParTitreInvers() {
		return dao.findByOrderByTitreDesc();
	}
/*
	@Override
	public List<Serie> listerSeriesTrieParAnneeCroissant1ereSaison() {
		return dao.findOrderBySaisonsAnneeAsc();
	}

	@Override
	public List<Serie> listerSeriesTrieParAnneeDecroissant1ereSaison() {
		return dao.findOrderBySaisonsAnneeDesc();
	}

	@Override
	public List<Serie> listerSeriesTrieParNombreEpisodesTotalAsc() {
		return dao.findOrderByNombreEpisodesTotalAsc();
	}

	@Override
	public List<Serie> listerSeriesTrieParNombreEpisodesTotalDesc() {
		return dao.findOrderByNombreEpisodesTotalDesc();
	}
*/
	@Override
	public List<Serie> listerSeriesParRealisateur(String real) {
		return dao.findDistinctBySaisonsRealisateurNomContainingOrSaisonsRealisateurPrenomContaining(real, real);
	}

	@Override
	public List<Serie> listerSeriesParActeur(String acteur) {
		return dao.findDistinctBySaisonsActeursNomContainingOrSaisonsActeursPrenomContaining(acteur, acteur);
	}

	@Override
	public List<Serie> listerSeriesParTitre(String titre) {
		return dao.findByTitreContaining(titre);
	}

	@Override
	public List<Acteur> listerTouslesActeurs() {
		return dao.findActeurs();
	}


}
