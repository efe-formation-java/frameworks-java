package fr.formation.service;

import fr.formation.entity.Acteur;
import fr.formation.entity.Serie;

import java.util.List;

public interface SerieService {

	void ajouterSerie(Serie f) throws ServiceException;
	void modifierSerie(Serie f) throws ServiceException;
	void supprimerSerie(Serie f);
	
	List<Serie> listerSeries();
	Serie trouverSerie(int id);

	List<Serie> listerSeriesTrieParTitre();

	List<Serie> listerSeriesTrieParTitreInvers();
/*
	List<Serie> listerSeriesTrieParAnneeCroissant1ereSaison();

	List<Serie> listerSeriesTrieParAnneeDecroissant1ereSaison();

	List<Serie> listerSeriesTrieParNombreEpisodesTotalAsc();
	List<Serie> listerSeriesTrieParNombreEpisodesTotalDesc();
*/
	List<Serie> listerSeriesParRealisateur(String real);

	List<Serie> listerSeriesParActeur(String acteur);

	List<Serie> listerSeriesParTitre(String titre);

	List<Acteur> listerTouslesActeurs();

}
