package fr.formation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import fr.formation.config.MusicienConfiguration;
import fr.formation.model.Musicien;

public class AppelSpringMusicienConfiguration {

	public static void main(String[] args) {
		
		ApplicationContext ac = new AnnotationConfigApplicationContext(MusicienConfiguration.class);
		
		Musicien mus = ac.getBean(Musicien.class);
		mus.jouerMorceau();
		
		
		System.out.println("Fin du programme");
	}

}
