package fr.formation.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;



@Component
public class Musicien {

	
	@Autowired
	private Instrument instrument;
	
	
	@Value("La 7eme de Beethoven")
	private String morceau;
	
	
	public Musicien() {
		System.out.println("Creation d'un Musicien");
	}
	
	// seul constructeur
	public Musicien(Instrument instrument, String morceau) {
		this.instrument = instrument;
		this.morceau = morceau;
	}

	public Instrument getInstrument() {
		return instrument;
	}

	public void setInstrument(Instrument instrument) {
		this.instrument = instrument;
	}

	public String getMorceau() {
		return morceau;
	}

	public void setMorceau(String morceau) {
		this.morceau = morceau;
	}

	public void jouerMorceau() {
		instrument.afficher();
		System.out.println("et je joue le morceau " + morceau);
		instrument.jouer();
	}
	
	
}
