package fr.formation.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import fr.formation.model.Instrument;
import fr.formation.model.Piano;
import fr.formation.model.Violon;

@Configuration
@ComponentScan(basePackages = "fr.formation.model")
public class InstrumentConfiguration {

	
	@Bean
	public Instrument getInstrument() {
		return new Piano();
	}
	
}
