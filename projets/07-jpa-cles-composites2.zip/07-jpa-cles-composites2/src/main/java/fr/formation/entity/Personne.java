package fr.formation.entity;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="PERSCOMPO2")

public class Personne {


	@EmbeddedId
	private PersonnePrimaryKey ppk;

	private int age;

	public Personne() {
	}

	public Personne(String nom, String prenom, int age) {
		ppk = new PersonnePrimaryKey(nom, prenom);
		this.age = age;
	}

	public String getNom() {
		return ppk.getNom();
	}

	public void setNom(String nom) {
		ppk.setNom(nom);;
	}

	public String getPrenom() {
		return ppk.getPrenom();
	}

	public void setPrenom(String prenom) {
		ppk.setPrenom(prenom);
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Personne [nom=" + ppk.getNom() + ", prenom=" + ppk.getPrenom() + ", age=" + age + "]";
	}

}
