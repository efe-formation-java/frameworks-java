package fr.formation.main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import fr.formation.entity.Personne;
import fr.formation.entity.PersonnePrimaryKey;

public class AppelJPA {
	
	
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("monpu");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		Personne p1 = new Personne("Legrand", "Joe", 55);
		Personne p2 = new Personne("Legrand", "Jack", 56);
		Personne p3 = new Personne("Legrand", "Joe", 56);
		
		et.begin();
		try {
			em.persist(p1);
			em.persist(p2);
		//	em.persist(p3);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			System.out.println("Probleme : " + e.getMessage());
		}
		
		System.out.println("Liste des personnes : ");
		List<Personne> liste = em.createQuery("from Personne p", Personne.class).getResultList();
		
		liste.forEach(p -> System.out.println(p));
		
		// Récuperation d'une personne / clé primaire
		
		PersonnePrimaryKey ppk = new PersonnePrimaryKey("Legrand", "Jack");
		Personne trouve = em.find(Personne.class, ppk);
		System.out.println("Legrand Jack : " + trouve);
		
		ppk = new PersonnePrimaryKey("Legrand", "Lucie");
		trouve = em.find(Personne.class, ppk);
		System.out.println("Legrand Lucie : " + trouve);
		
		
		em.close();
		emf.close();
	}
}
