package fr.formation.main;

import java.util.List;

import fr.formation.dal.CapitaleDao;
import fr.formation.dal.DaoUtil;
import fr.formation.dal.PaysDao;
import fr.formation.entity.Capitale;
import fr.formation.entity.Pays;

public class TestOTO {

	public static void main(String[] args) {
		
		Capitale c1 = new Capitale("Paris");
		Pays p1 = new Pays("France", c1); 
		
		PaysDao pDao = new PaysDao();
		pDao.add(p1);
		
		
		Pays p2 = new Pays("Italie");
		Capitale c2 = new Capitale("Rome", p2);
		CapitaleDao cDao = new CapitaleDao();
		cDao.add(c2);
		
		List<Pays> listeP = pDao.findAll();
		System.out.println("\nListe des pays :");
		listeP.forEach(p -> System.out.println(p));
		
		
		List<Capitale> listeC = cDao.findAll();
		System.out.println("\nListe des capitales :");
		listeC.forEach(c -> System.out.println(c));
		
		pDao.delete(p1);
		
		cDao.delete(c2);
		
		DaoUtil.close();
	}

}
