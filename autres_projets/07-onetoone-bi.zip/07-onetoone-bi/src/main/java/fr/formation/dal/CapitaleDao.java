package fr.formation.dal;

import java.util.List;

import javax.persistence.EntityManager;

import fr.formation.entity.Capitale;
import fr.formation.entity.Pays;

public class CapitaleDao {

	private EntityManager em;
	
	public CapitaleDao() {
		em = DaoUtil.getEntityManager();
	}
	
	
	public void add(Capitale c) {
		em.getTransaction().begin();
		
		try {
			em.persist(c);
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		}
	}
	
	public List<Capitale> findAll(){
		return em
				.createQuery("Select c From Capitale c", Capitale.class)
				.getResultList();
	}
	
	public Capitale findById(int id) {
		return em.find(Capitale.class, id);
	}


	public void update(Capitale c) {
		em.getTransaction().begin();
		
		try {
			em.merge(c);
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		}
	}
	
	
	public void delete(Capitale c) {
		em.getTransaction().begin();
		
		try {
			em.remove(c);
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		}
	}
}
