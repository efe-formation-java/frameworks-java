package fr.formation.main;

import fr.formation.dal.DaoUtil;
import fr.formation.dal.PaysDao;
import fr.formation.entity.Pays;

public class GestionPays {

	public static void main(String[] args) {
		
		PaysDao pDao = new PaysDao();
		pDao.add(new Pays("gr", "Grece"));
		pDao.add(new Pays("es", "Espagne"));
		pDao.add(new Pays("pt", "Portugal"));
		pDao.add(new Pays("it", "Italie"));
		pDao.add(new Pays("is", "Islande"));
		
		
		DaoUtil.close();
	}

}
