package fr.formation.main;

import java.util.ArrayList;
import java.util.List;

import fr.formation.dal.DaoUtil;
import fr.formation.dal.PaysDao;
import fr.formation.dal.PersonneDao;
import fr.formation.entity.Pays;
import fr.formation.entity.Personne;

public class GestionPersonnes {

	public static void main(String[] args) {
		
		PaysDao pDao = new PaysDao();
		Pays es = pDao.findById("es");
		Pays it = pDao.findById("it");
		Pays pt = pDao.findById("pt");
		
		List<Pays> liste1 = new ArrayList<Pays>();
		liste1.add(es);
		liste1.add(pt);
		liste1.add(it);
		Personne p1 = new Personne("Legrand", "Joe", liste1);
		
		List<Pays> liste2 = new ArrayList<Pays>();
		liste2.add(es);
		liste2.add(pt);
		liste2.add(pDao.findById("is"));
		liste2.add(pDao.findById("gr"));
		Personne p2 = new Personne("Lepetit", "Aline", liste2);
		
		PersonneDao persDao = new PersonneDao();
		persDao.add(p1);
		persDao.add(p2);
		
		DaoUtil.close();
	}

}
