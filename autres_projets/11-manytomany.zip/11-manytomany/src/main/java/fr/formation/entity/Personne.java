package fr.formation.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Personne_MTM")
public class Personne {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String nom;
	private String prenom;
	
	@ManyToMany  // les ToMany sont en LAZY par défaut
	private List<Pays> paysVisites;

	public Personne() {
	}
	public Personne(String nom, String prenom, List<Pays> paysVisites) {
		this.nom = nom;
		this.prenom = prenom;
		this.paysVisites = paysVisites;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public List<Pays> getPaysVisites() {
		return paysVisites;
	}
	public void setPaysVisites(List<Pays> paysVisites) {
		this.paysVisites = paysVisites;
	}
	@Override
	public String toString() {
		return "Personne [id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", paysVisites=" + paysVisites + "]";
	}
	
	
	
	
}
