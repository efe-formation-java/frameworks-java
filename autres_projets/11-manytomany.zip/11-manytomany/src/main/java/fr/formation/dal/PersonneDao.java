package fr.formation.dal;

import java.util.List;

import javax.persistence.EntityManager;

import fr.formation.entity.Personne;

public class PersonneDao {

	private EntityManager em;
	
	public PersonneDao() {
		em = DaoUtil.getEntityManager();
	}
	
	
	public void add(Personne p) {
		em.getTransaction().begin();
		
		try {
			em.persist(p);
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		}
	}
	
	public List<Personne> findAll(){
		return em
				.createQuery("Select p From Personne p", Personne.class)
				.getResultList();
	}
	
	public Personne findById(int id) {
		return em.find(Personne.class, id);
	}


	public void update(Personne p) {
		em.getTransaction().begin();
		
		try {
			em.merge(p);
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		}
	}
	
	
	public void delete(Personne p) {
		em.getTransaction().begin();
		
		try {
			em.remove(p);
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			em.getTransaction().rollback();
		}
	}
}
