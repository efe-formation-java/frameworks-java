package fr.formation.entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("V")
public class Voiture extends VoitureAbstract {

	
	public Voiture() {
		super();
	}
	
	public Voiture(String marque) {
		super(marque);
	}

	@Override
	public String toString() {
		return "Voiture [" + super.toString() + "]";
	}
	
	
	
}
