package fr.formation.entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("B")
public class Berline extends VoitureAbstract {

	
	private String couleurCuir;
	
	public Berline() {
		super();
	}
	
	public Berline(String marque, String couleur) {
		super(marque);
		this.couleurCuir = couleur;
	}

	public String getCouleurCuir() {
		return couleurCuir;
	}

	public void setCouleurCuir(String couleurCuir) {
		this.couleurCuir = couleurCuir;
	}

	@Override
	public String toString() {
		return "Berline [couleurCuir=" + couleurCuir + ", " + super.toString() + "]";
	}
	
	
	
}

