package fr.formation.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "TPCVoiture")
public class Voiture extends VoitureAbstract {

	
	public Voiture() {
		super();
	}
	
	public Voiture(String marque) {
		super(marque);
	}

	@Override
	public String toString() {
		return "Voiture [" + super.toString() + "]";
	}
	
	
	
}
